//How do we know we need a loop?
    //Because we are performing the same operation multiple times
//What's the starting point of the loop?
    //2 miles
//When should the loop stop?
    //Mile 6
//How will the loop know when to stop?
    //Loop will return a false response to the test expression
//What's incrementing for each iteration of the loop?
    //the miles ran (incrementing by 2)
//What variables do we need?
    //Number of miles ran, mph (bonus)

var numMiles = 0

for (numMiles=0; numMiles<=6; numMiles=numMiles+2)
{
    if (numMiles!=0)
    {
        console.log("Here's your candy")
    }
}
//bonus
var numMiles = 0
var mph = 5.5
for (numMiles=0; numMiles<=6; numMiles=numMiles+2)
{
    if (numMiles!=0)
    {
        if (mph >= 5.5)
        {
            console.log("Here's your candy")
        }
        
    }
}