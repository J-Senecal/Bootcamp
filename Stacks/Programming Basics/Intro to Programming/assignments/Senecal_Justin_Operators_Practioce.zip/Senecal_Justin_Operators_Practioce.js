function howMuchLeftOverCake(numberOfPieces, numberOfPeople) {
    var leftovers = (numberOfPieces - numberOfPeople);
    if (leftovers == 0) {
        return "No leftovers for you!"
        }
    if (leftovers <= 2) {
        return "You have some leftovers"
        }
    if (leftovers >= 3 && leftovers <=5){
        return "You have leftovers to share"
    }
    if (leftovers > 5){
        return "Hold another party!"
    }
}
console.log(howMuchLeftOverCake(12,5))