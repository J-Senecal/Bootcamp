function greet(name, time) {
    if (name == "Count Dooku"){
        console.log( "I'm coming for you, Dooku!");
    }
    else {
        console.log("good day", name, "it's", time);
    }
}

greet("annakin", "11 am")