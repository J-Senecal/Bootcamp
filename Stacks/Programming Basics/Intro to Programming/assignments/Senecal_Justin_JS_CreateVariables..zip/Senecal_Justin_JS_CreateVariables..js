//minimum age in year
var minAge = 10
//minimum height in inches
var minHeight = 42
