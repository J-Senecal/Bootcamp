function disappear(addDef){
    addDef.remove();
}

function changeText(navButton){
    navButton.innerText = "Logout";
}