// display current number of likes
var likeCount = 0;
//  execute program to increase likes -
function increaseLikes() {
    // parameters of the function to run 
    likeCount = likeCount + 1;
}
