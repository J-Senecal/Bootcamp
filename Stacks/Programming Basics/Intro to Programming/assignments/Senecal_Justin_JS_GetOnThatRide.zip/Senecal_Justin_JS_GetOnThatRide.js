let minAge = 10;
let minHeight = 42;
let riderAge = 10;
let riderHeight = 42;

if (riderHeight >= minHeight)
{
    console.log('Get on that ride Kiddo!');
}

else 
{
    console.log('Sorry kiddo. Maybe next year');
}
//stretch 1
if (riderHeight >= minHeight && riderAge >= minAge)
{
    console.log('Get on that ride Kiddo!');
}
//stretch 2
if (riderHeight >= minHeight || riderAge >= minAge)
{
    console.log('Get on that ride Kiddo!');
}